﻿using static Sorting;
using static Infrastructure;

// int[] array = CreateArray(10);
// Show(array);
// SortSelection(array);
// Show(array);

10.CreateArray()
  .Show()
  .SortBubbleOptimized()
  .Show();

